package mesmaths;

public class TestMesMaths
{

/**
 * @param args
 */
public static void main(String[] args)
{

double a0, a1, a2, a3;

a0 = -48;
a1 = 52;
a2 = -18;
a3 = 2; // les z�ros sont 2, 3 et 4

/*
a0 = -4;
a1 = 2;
a2 = -4;
a3 = 2; // le z�ro est 2
*/

double [] t = MesMaths.r�soutEquationDegr�3(a0, a1, a2, a3);

int i;

for ( i = 0; i < t.length; ++i)
    System.out.println(t[i]);

}

}
